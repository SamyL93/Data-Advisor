-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 12, 2021 at 05:38 PM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `dataadvisor`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `titre`, `description`, `created_at`, `url`, `image`) VALUES
(1, 'Sur la 5G, ce qui est vrai, ce qui est faux et ce qu’on ne sait pas encore\r\n', 'Le déploiement de la 5G, dont les premières fréquences sont activées mercredi 18 novembre en France, permettra d’avoir un débit Internet plus important, surtout utile pour les entreprises. ', '2020-09-24 12:00:00', 'https://www.lemonde.fr/les-decodeurs/article/2020/09/24/5g-le-vrai-le-faux-et-ce-qu-on-ne-sait-pas-encore_6053447_4355770.html', 'uploads/article/monde.png'),
(5, 'Quel est le calendrier de la 5G en France ?', 'La construction du réseau 5G en France prendra dix ans. Depuis le 1er novembre, un premier réseau commercial, embryonnaire, est allumé en France. Numerama vous propose un récapitulatif des grandes échéances à venir pour l\'ultra haut débit mobile.', '2020-11-20 00:00:00', 'https://www.numerama.com/politique/312368-deploiement-de-la-5g-quel-est-le-calendrier-defini-par-leurope.html', 'uploads/article/EAkjhEzXZFAhfQhzhSZV9yXUWRJ4h5MA.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
