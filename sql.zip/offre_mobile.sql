-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 12, 2021 at 05:40 PM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `dataadvisor`
--

-- --------------------------------------------------------

--
-- Table structure for table `offre_mobile`
--

CREATE TABLE `offre_mobile` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prix` double DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operateur` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offre_mobile`
--

INSERT INTO `offre_mobile` (`id`, `titre`, `image`, `prix`, `url`, `operateur`, `data`, `type`) VALUES
(1, 'Free Série Spéciale', 'uploads/mobile/7zSu7gyBnjQJzbtS7nx1gir3KRJcPJP3.png', 19.99, 'http://mobile.free.fr/?pk_campaign=Comparateurs-FilRouge&pk_source=puremium&t=102ab2faec9712035bace426d2dfe4&s=1053', 'FREE', '150 Go', '5G'),
(2, 'SFR FORFAIT 100 GO 5G', 'uploads/mobile/2t8JNCcn6xW45mX3ekg5MzSMneH1Wffp.jpeg', 35, 'https://www.sfr.fr/offre-mobile/forfait-100go-5g', 'SFR', '100 Go', '5G'),
(3, 'Orange Forfait 2h 100 Mo', 'uploads/mobile/vSaijunRxWhb5y59acxEjieTaf9uKCRS.jpeg', 2.99, 'https://m.boutique.orange.fr/mobile/offre/forfait-2h-100mo', 'ORANGE', '100 Mo', '4G');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `offre_mobile`
--
ALTER TABLE `offre_mobile`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `offre_mobile`
--
ALTER TABLE `offre_mobile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
