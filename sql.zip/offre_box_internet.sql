-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 12, 2021 at 05:39 PM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `dataadvisor`
--

-- --------------------------------------------------------

--
-- Table structure for table `offre_box_internet`
--

CREATE TABLE `offre_box_internet` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prix` double DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operateur` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offre_box_internet`
--

INSERT INTO `offre_box_internet` (`id`, `titre`, `image`, `prix`, `url`, `operateur`, `type`) VALUES
(1, 'Offre Coup de Pouce Livebox', 'uploads/box-internet/ni3bUQmq6sFLZjwDKzexmnWdBArjaNX9.gif', 19.99, 'https://boutique.orange.fr/internet/offre-sociale', 'ORANGE', 'FIBRE'),
(2, 'Box 4G+', 'uploads/box-internet/h2kYWi3MJp7f8h2QVYBVgiLqvs61WUCk.jpeg', 29.99, 'https://www.free.fr/freebox/', 'FREE', 'FIBRE'),
(3, 'Red Box DSL', 'uploads/box-internet/T93V9ZVhaJ2co1wP56R54zhP6h1xtDH3.jpeg', 21, 'https://www.red-by-sfr.fr/', 'SFR', 'FIBRE'),
(4, 'Red Box DSL Zone dégroupée', 'uploads/box-internet/7upZzq3oxHk72wDB3RoxDP63fL1bDUWz.jpeg', 21, 'https://www.red-by-sfr.fr/', 'SFR', 'ADSL'),
(5, 'Bbox Fit Fibre', 'uploads/box-internet/GpWAb8ekDDis6WizaJH8e3cnzjbdcCwn.jpeg', 29.99, 'https://www.bouyguestelecom.fr/offres-internet', 'BOUY', 'FIBRE'),
(6, 'Free Box 4G+', 'uploads/box-internet/78aM9MS6GjfU1gB5UJtVrrg87dDTCw2a.png', 29.99, 'https://www.free.fr/freebox/', 'FREE', '4G'),
(7, 'SFR ADSL Box 7', 'uploads/box-internet/5s8QUX4cdtXfEJXdEGYqwYcFPAQFB6Q1.png', 33, 'https://www.sfr.fr/offre-internet', 'SFR', 'ADSL'),
(8, 'Bouygue Bbox Must', 'uploads/box-internet/jwt8TdJswNNVARvqX4Pv6tPjNZLmzTT9.jpeg', 33.99, 'https://www.bouyguestelecom.fr/offres-internet', 'BOUY', 'ADSL'),
(9, 'Free Mini 4K', 'uploads/box-internet/fwTSfa7GTHkvr4ESHr3CLZ1SBZbGNwjc.png', 34.99, 'https://www.free.fr/freebox/', 'FREE', 'FIBRE'),
(10, 'Free Mini 4K', 'uploads/box-internet/s6zzCadHz8TUkLzdRmEg4fejGV7B2LAu.png', 34.99, 'https://www.free.fr/freebox/', 'FREE', 'ADSL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `offre_box_internet`
--
ALTER TABLE `offre_box_internet`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `offre_box_internet`
--
ALTER TABLE `offre_box_internet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
