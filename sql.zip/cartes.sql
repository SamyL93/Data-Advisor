-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 12, 2021 at 05:34 PM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `dataadvisor`
--

-- --------------------------------------------------------

--
-- Table structure for table `carte`
--

CREATE TABLE `carte` (
  `id` int(11) NOT NULL,
  `json` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carte`
--

INSERT INTO `carte` (`id`, `json`, `identifier`) VALUES
(12, 'uploads/cartes/EX7WcA8rQ4hCJrZQymKLD6UhkwsjqYRk.json', '5G'),
(13, 'uploads/cartes/oiy9nzKpooQoX3VdGeKqYsY7zLGpJ87P.json', 'BOUY_2G'),
(14, 'uploads/cartes/hyaA2woBo4oQqccpLtpfZnnUAueh7eoD.json', 'BOUY_3G'),
(15, 'uploads/cartes/BHD2dckoGzgo4rHhjQaDMhh6jKTSmpi7.json', 'BOUY_4G'),
(16, 'uploads/cartes/H6h1cRmPjo2XK4m5rvUu37PZ3DCxPeqM.json', 'FREE_2G'),
(17, 'uploads/cartes/ZsFLfCzy9gqPCh7GtkW55Vm5uyZXnGNx.json', 'FREE_3G'),
(18, 'uploads/cartes/XeL4u7dTFxnJWYCAcGvnKXTQrNAQD2jU.json', 'FREE_4G'),
(19, 'uploads/cartes/gWRAPJFFg96aWeRVLtofDw7ZuRS7xsrK.json', 'ORANGE_4G'),
(20, 'uploads/cartes/osMMeEax3SDtTHS4FMwAXyxF4znpZL3d.json', 'ORANGE_2G'),
(21, 'uploads/cartes/nNuDbg1uw1g7wgHd3WaKogoSNaWXJyuV.json', 'ORANGE_3G'),
(22, 'uploads/cartes/iXhsu9QEmZXtP7FN87AMUmusqvE9yUu6.json', 'SFR_2G'),
(23, 'uploads/cartes/KMD7qDuvrLsX6TDSZY3pqEcJLYMWTuJJ.json', 'SFR_3G'),
(24, 'uploads/cartes/jes6oRQ74DSESKtHVBxbUEc154uPtqa5.json', 'SFR_4G'),
(25, 'uploads/cartes/HLxb8gSZJTZAJpHYBg9uqYyjVTaN9McB.json', 'FIBRE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carte`
--
ALTER TABLE `carte`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carte`
--
ALTER TABLE `carte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
